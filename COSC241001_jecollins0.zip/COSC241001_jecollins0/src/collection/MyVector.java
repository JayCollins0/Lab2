package collection;

public class MyVector implements Cloneable {
    public Object[] elements;
    private final int capactity=25;
    private int realSize;
    
    public MyVector(){
        elements=new Object[capactity];
        realSize=0;
    }
    
    //to double the length of vector whenever it reaches maximum capacity
    private void doubleLength(){
        Object[] placeholder=new Object[2*(elements.length)];
        for(int i=0;i<realSize;++i){
            placeholder[i]=elements[i];
        }
        elements=placeholder;
    }
    
    public void append(Object element){
        if(realSize==elements.length){
            doubleLength();
        }
        elements[realSize]=element;
        realSize++;
    }
    public void clear(){
        for (int i=0; i<realSize;i++){
            elements[i]=null;
        }
        realSize=0;
    }
    public boolean contains(Object element){
        boolean found=false;
        int index=0;
        while(index<realSize&&!found){
            if(elements[index]==element){
                found=true;
            }
            index++;
        }
        return found;
    }
    public Object elementAt(int index){
        if(index<0||index>=realSize){
            return "invalid index\n";
        }
        return elements[index];
    }
    public int indexOf(Object element){
        int index = -1;
        for(int i=0; i<realSize;i++){
            if(elements[i]==element){
                index=i;
            }
        }
        return index;
    }
    public void insertAt(int index, Object element){
        if(realSize==elements.length){
            doubleLength();
        }
        if (index<0||realSize<index) {
            System.out.println("The given index was either too large or too small; action not performed.");
        }
        for(int i=realSize-1;i>=index;i--){
            elements[i+1]=elements[i];
        }
        elements[index]=element;
        realSize++;
    }
    public boolean isEmpty(){
        return realSize==0;
    }
    public Object removeAt(int index){
        if (index<0||index>=elements.length) {
            return null;
        }else{
            Object temp = elements[index];
            while(index<realSize-1){
                elements[index]=elements[index+1];
                index++;
            }
            elements[--realSize]=null;
            return temp;

        }
    }
    
    public void remove(Object element){
        for(int i=0; i<realSize;i++){
            if(elements[i]==element){
                removeAt(i);
                //realSize-- included in removeAt method
            }
            break;
        }
    }
    public void replace(int index, Object element){
        if (index<0||index>realSize-1) {
            System.out.println("The given index was either too large or too small; action not performed.");
        }
        elements[index]=element;
    }
    public int size(){
        int counter=0;
        for (int i=0;i<elements.length;i++){
            if(elements[i]!=null)
                counter++;
        }
        realSize=counter;
        return counter;
    }
    public void ensureCapacity(int minCapacity){
        while(minCapacity>elements.length){
            doubleLength();
        }
    }
    public MyVector clone(){
        MyVector clone=new MyVector();
        for(int i=0; i<elements.length;i++){
            clone.append(elements[i]);
        }
        return clone;
    }
    public void removeRange(int fromIndex, int toIndex){
        if (fromIndex<0)
            System.out.println("Invalid lower index");
        if (toIndex>=realSize)
            toIndex=realSize;
        int total=toIndex-fromIndex;
        for(int i=fromIndex; i<(realSize-total);++i){
            elements[i]=elements[i+total];
        }
        for(int j=(realSize-total); j<realSize;++j){
            elements[j]=null;
        }
        realSize=realSize-total;
    }
    public String toString(){
        String str = "";
        for (int i=0; i<realSize; i++) {
            str=str+ i+":"+elements[i]+"\t\t";
            if((i+1)%5==0)
                str=str+"\n";
        }
        return str;
    }
    public void reverse(){
        Object[] placeholder=new Object[elements.length];
        int j=elements.length;
        for(int i=0;i<elements.length;i++){
            placeholder[j-1]=elements[i];
            j--;
        }
        for(int i=0;i<elements.length;i++){
            elements[i]=placeholder[i];
        }
    }
    
    public void merge(MyVector vector2){
        MyVector test=new MyVector();
        int size2=vector2.size();
        for(int i=0; i<elements.length;i++){
            if(realSize==elements.length){
                doubleLength();
            }
            elements[realSize]=vector2.elementAt(i);
            //vector2.append(elements[i]);
            realSize++;
        }
        //for(int i=0;i<size2;i++){
            
        }
        //realSize=realSize+size2;
    }
    

