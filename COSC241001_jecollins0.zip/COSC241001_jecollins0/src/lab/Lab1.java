package lab;
import java.util.*;
public class Lab1 {
    public static void test(String[] args){
	    Vector<Object> vector=new Vector<Object>();
	    int primitiveInt=241;
	    Integer wrapperInt=new Integer(1234);
	    String str="Jay";
	    vector.add(primitiveInt);
	    vector.add(wrapperInt);
	    vector.add(str);
	    vector.add(2, new Integer(2138));
	    System.out.println("The elements of vector: "+ vector);
	    System.out.println("The size of vector is: "+vector.size());
	    System.out.println("The element at position 2 is: "+ vector.elementAt(2));
	    System.out.println("The first element of vector is: "+ vector.firstElement());
	    System.out.println("The last element of vector is: "+ vector.lastElement());
	    vector.removeElementAt(1);
	    System.out.println("The elements of vector: "+ vector);
	    System.out.println("The size of vector is: "+vector.size());
	    System.out.println("The element at position 2 is: "+ vector.elementAt(2));
	    System.out.println("The first element of vector is: "+ vector.firstElement());
	    System.out.println("The last element of vector is: "+ vector.lastElement());
            Random rand=new Random();
            int int1=rand.nextInt(100);
            int int2=rand.nextInt(100);
            int int3=rand.nextInt(100);
            vector.add(int1);
            vector.add(int2);
            vector.add(int3);
            System.out.println("The new elements of the vector: "+ vector);
            for(int i=1;i<=vector.size();i++){
                vector.removeElementAt(i);
            }
            System.out.println("The elements left in the vector: "+ vector);
    }
}

