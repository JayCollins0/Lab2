package lab;

import collection.*;

public class Lab2 {

    public static void test() {
        MyVector vec = new MyVector();
        
        vec.insertAt(0,0);
        vec.insertAt(1,1);
        int fib, fib1, fib2;
        for (int i=2; i<25 ;i++) {
            fib1=(int) vec.elementAt(i-1);
            fib2=(int) vec.elementAt(i-2);
            fib=fib1+fib2;
            vec.insertAt(i,fib);
        }
        
        System.out.println("Original Vector:\n"+vec);
        
        vec.reverse();
        
        MyVector clone=vec.clone();
        
        System.out.println("Original Vector:\n"+vec);
        
        //remove any objects at odd indexes
        int n=vec.size();
        for (int i=n;i>=0;i=i-2){
            vec.removeAt(i);
        }
        
        System.out.println("Original Vector:\n"+vec+"\n");
        
        clone.reverse();
        
        System.out.println("Clone Vector:\n"+clone);
        
        vec.merge(clone);
        
        System.out.println("Original Vector:\n"+vec);
    }
}
