package main;

import lab.*;

public class Main {
    public static void main(String[] args) {
	   Lab2.test();
	}
}
